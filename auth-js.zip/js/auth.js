// Daftar akun contoh (untuk simulasi)
const daftarAkun = [
  { username: "penghuni1", password: "123", nama: "Penghuni Kamar A1", role: "penghuni" },
  { username: "pengurus", password: "123", nama: "Pengurus UKS Asrama", role: "admin" }
];

// Proses saat form login disubmit
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const userInput = document.getElementById("username").value.trim();
    const passInput = document.getElementById("password").value.trim();
    const errorMsg = document.getElementById("errorMsg");

    const akunCocok = daftarAkun.find(
      (akun) => akun.username === userInput && akun.password === passInput
    );

    if (akunCocok) {
      // Simpan status login di sessionStorage
      sessionStorage.setItem("userLogin", JSON.stringify(akunCocok));
      window.location.href = "index.html";
    } else {
      errorMsg.textContent = "Username atau kata sandi salah!";
      errorMsg.style.display = "block";
    }
  });
}

// Fungsi cek status login di halaman utama (index.html)
function cekLogin() {
  const user = JSON.parse(sessionStorage.getItem("userLogin"));
  const infoUser = document.getElementById("infoUser");

  if (!user) {
    // Arahkan ke halaman login jika belum masuk
    window.location.href = "login.html";
    return;
  }

  if (infoUser) {
    infoUser.textContent = `Halo, ${user.nama}`;
  }
}

// Fungsi logout
function logout() {
  sessionStorage.removeItem("userLogin");
  window.location.href = "login.html";
}
