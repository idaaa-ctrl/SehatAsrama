# 🌟 SehatAsrama - Portal Kesehatan Pelajar

Website informasi kesehatan asrama dengan desain colorful dan ramah pelajar, dilengkapi halaman login simulasi.

## 📁 Struktur Folder
- `index.html` — Halaman utama (informasi permasalahan kesehatan, tips sehat, dan kontak bantuan)
- `login.html` — Halaman login penghuni asrama
- `css/style.css` — Styling ceria & responsif
- `js/auth.js` — Logika autentikasi login & logout berbasis `sessionStorage`

## 🔑 Akun Simulasi untuk Login
- **Username:** `penghuni1` | **Password:** `123`
- **Username:** `pengurus` | **Password:** `123`

## 🚀 Cara Deploy ke GitHub Pages
1. Upload seluruh isi folder ini ke repository GitHub (pastikan `index.html` berada di root repository).
2. Buka **Settings > Pages**.
3. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
